
from django.contrib import admin
from django.urls import path
from todos.views import (
    todo_list_view,
    todo_create_view,
    todo_update_view,
    todo_delete_view,
    todo_complete_view,
)

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", todo_list_view, name='todo_list'),
    path("create", todo_create_view, name='todo_create'),
    path("update/<int:pk>/", todo_update_view, name='todo_update'),
    path("delete/<int:pk>/", todo_delete_view, name='todo_delete'),
    path("complete/<int:pk>/", todo_complete_view, name='todo_complete')
]