#from datetime import date#
from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse_lazy
from .models import Todo
from .forms import TodoForm
import sys

# Todo List View
def todo_list_view(request):
    todos = Todo.objects.all()
    print(todos)
    sys.exit()
    return render(request, 'todo_list.html', {'todo':todos})

# Todo Create View
def todo_create_view(request):
    if request.method == "POST":
        form = TodoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('todo_list')
    else:
        form = TodoForm()
    return render(request, 'todo_form.html', {'form': form})

# Todo Update View
def todo_update_view(request, pk):
    todo = get_object_or_404(Todo, pk=pk)
    if request.method == "POST":
        form = TodoForm(request.POST, instance=todo)
        if form.is_valid():
            form.save()
            return redirect('todo_list')
    else:
        form = TodoForm(instance=todo)
    return render(request, 'todo_form.html', {'form': form})

# Todo Delete View
def todo_delete_view(request, pk):
    todo = get_object_or_404(Todo, pk=pk)
    if request.method == "POST":
        todo.delete()
        return redirect('todo_list')
    return render(request, 'todo_confirm_delete.html', {'todo': todo})

# Todo Complete View
def todo_complete_view(request, pk):
    todo = get_object_or_404(Todo, pk=pk)
    todo.mark_has_complete()
    return redirect('todo_list')